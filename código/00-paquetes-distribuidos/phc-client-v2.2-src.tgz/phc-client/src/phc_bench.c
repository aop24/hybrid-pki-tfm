/*
 * phc-bench: performance measurements for block 13 (RNF1).
 *
 *   phc-bench sig <alg> <n> <warmup> <csv>
 *       Sign and verify a 1024-byte message with a fresh key of <alg>:
 *       rsa4096 | ecdsa-p256 | ecdsa-p384 | ecdsa-p521 | mldsa65 | mldsa87 | p384_mldsa65 | p521_mldsa87
 *       (ECDSA P-384/P-521 with SHA-384/SHA-512: the classic components of the composites)
 *
 *   phc-bench verify <model> <cert> <ca-bundle> <n> <warmup> <csv>
 *       Per iteration: standard X.509 chain validation (X509_verify_cert, root
 *       self-signature included) and phc hybrid verification of the same chain.
 *
 *   phc-bench tls-server <port> <cert> <key> <ca-bundle>
 *       Accepts connections forever: TLS 1.3 handshake, hybrid verification of
 *       the client chain, close.
 *
 *   phc-bench tls-client <model> <host> <port> <cert> <key> <ca-bundle> <n> <warmup> <csv>
 *       n full handshakes (new TCP connection, no resumption, X25519 only):
 *       TCP connect, TLS handshake, hybrid verification of the server chain and
 *       bytes exchanged during the handshake.
 *
 * PHC_BENCH_PAUSE_MS (tls-client): pause between handshakes, so that the server
 *   finishes the work of the previous connection (hybrid verification of the
 *   client chain) before the next one starts. Default 0. Recorded in the CSV.
 *
 * Chain sent in TLS (server and client), environment variable PHC_CHAIN:
 *   auto      (default, as phc-msg/file/challenge) OpenSSL builds the chain from
 *             the trust store and sends leaf + intermediate + root.
 *   explicit  SSL_MODE_NO_AUTO_CHAIN: exactly the certificates of <cert>
 *             (give a file with leaf + intermediate).
 *
 * Phases written to the CSV: "warmup" for the first <warmup> iterations,
 * "measure" for the rest. With n = 1 and warmup = 0 the single sample is
 * labelled "cold" (first operation of a fresh process).
 * Rows are appended; the header is written only if the file is new.
 */
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509_vfy.h>

#include "phc.h"

#define MSG_LEN 1024

static FILE *open_csv(const char *path, const char *header)
{
    FILE *f = fopen(path, "a+");
    if (!f) {
        perror(path);
        exit(1);
    }
    fseek(f, 0, SEEK_END);
    if (ftell(f) == 0)
        fprintf(f, "%s\n", header);
    return f;
}

static const char *phase(int i, int n, int warmup)
{
    if (n == 1 && warmup == 0)
        return "cold";
    return i < warmup ? "warmup" : "measure";
}

static char g_host[64];

/* ---------------- sig ---------------- */

static EVP_PKEY *gen_key(const char *alg, const char **md)
{
    EVP_PKEY *pkey = NULL;
    *md = NULL;
    if (strcmp(alg, "rsa4096") == 0) {
        pkey = EVP_PKEY_Q_keygen(NULL, NULL, "RSA", (size_t)4096);
        *md = "SHA256";
    } else if (strcmp(alg, "ecdsa-p256") == 0) {
        pkey = EVP_PKEY_Q_keygen(NULL, NULL, "EC", "P-256");
        *md = "SHA256";
    } else if (strcmp(alg, "ecdsa-p384") == 0) {
        pkey = EVP_PKEY_Q_keygen(NULL, NULL, "EC", "P-384");
        *md = "SHA384";
    } else if (strcmp(alg, "ecdsa-p521") == 0) {
        pkey = EVP_PKEY_Q_keygen(NULL, NULL, "EC", "P-521");
        *md = "SHA512";
    } else {
        EVP_PKEY_CTX *c = EVP_PKEY_CTX_new_from_name(NULL, alg, NULL);
        if (c && EVP_PKEY_keygen_init(c) > 0)
            EVP_PKEY_generate(c, &pkey);
        EVP_PKEY_CTX_free(c);
    }
    return pkey;
}

static int cmd_sig(int argc, char **argv)
{
    if (argc != 6) {
        fprintf(stderr, "usage: phc-bench sig <alg> <n> <warmup> <csv>\n");
        return 2;
    }
    const char *alg = argv[2];
    int n = atoi(argv[3]), warmup = atoi(argv[4]);
    const char *md;
    EVP_PKEY *pkey = gen_key(alg, &md);
    if (!pkey) {
        fprintf(stderr, "cannot generate key for %s\n", alg);
        ERR_print_errors_fp(stderr);
        return 1;
    }
    unsigned char msg[MSG_LEN];
    RAND_bytes(msg, sizeof msg);
    FILE *csv = open_csv(argv[5], "host,alg,op,phase,iter,ms,sig_bytes");

    for (int i = 0; i < n; i++) {
        size_t sig_len = 0;
        unsigned char *sig = NULL;
        EVP_MD_CTX *s = EVP_MD_CTX_new();
        double t0 = phc_now_ms();
        int ok = EVP_DigestSignInit_ex(s, NULL, md, NULL, NULL, pkey, NULL) == 1 &&
                 EVP_DigestSign(s, NULL, &sig_len, msg, sizeof msg) == 1 &&
                 (sig = malloc(sig_len)) != NULL &&
                 EVP_DigestSign(s, sig, &sig_len, msg, sizeof msg) == 1;
        double t_sign = phc_now_ms() - t0;
        EVP_MD_CTX_free(s);

        EVP_MD_CTX *v = EVP_MD_CTX_new();
        t0 = phc_now_ms();
        ok = ok && EVP_DigestVerifyInit_ex(v, NULL, md, NULL, NULL, pkey, NULL) == 1 &&
             EVP_DigestVerify(v, sig, sig_len, msg, sizeof msg) == 1;
        double t_verify = phc_now_ms() - t0;
        EVP_MD_CTX_free(v);
        free(sig);
        if (!ok) {
            fprintf(stderr, "sign/verify failed for %s\n", alg);
            ERR_print_errors_fp(stderr);
            return 1;
        }
        const char *ph = phase(i, n, warmup);
        fprintf(csv, "%s,%s,sign,%s,%d,%.4f,%zu\n", g_host, alg, ph, i, t_sign, sig_len);
        fprintf(csv, "%s,%s,verify,%s,%d,%.4f,%zu\n", g_host, alg, ph, i, t_verify, sig_len);
    }
    fclose(csv);
    EVP_PKEY_free(pkey);
    printf("sig %s: %d iterations (%d warm-up) -> %s\n", alg, n, n == 1 && warmup == 0 ? 0 : warmup, argv[5]);
    return 0;
}

/* ---------------- verify ---------------- */

static X509 *load_cert(const char *path)
{
    FILE *f = fopen(path, "r");
    X509 *c = f ? PEM_read_X509(f, NULL, NULL, NULL) : NULL;
    if (f)
        fclose(f);
    return c;
}

static int cmd_verify(int argc, char **argv)
{
    if (argc != 8) {
        fprintf(stderr, "usage: phc-bench verify <model> <cert> <ca-bundle> <n> <warmup> <csv>\n");
        return 2;
    }
    const char *model = argv[2];
    X509 *cert = load_cert(argv[3]);
    X509_STORE *store = X509_STORE_new();
    int n = atoi(argv[5]), warmup = atoi(argv[6]);
    if (!cert || !store || X509_STORE_load_file(store, argv[4]) != 1) {
        fprintf(stderr, "cannot load certificate or CA bundle\n");
        return 1;
    }
    /* Also verify the self-signature of the root, so that both methods cover the same links */
    X509_STORE_set_flags(store, X509_V_FLAG_CHECK_SS_SIGNATURE);
    FILE *csv = open_csv(argv[7], "host,model,phase,iter,x509_ms,hybrid_ms,chain_len");

    for (int i = 0; i < n; i++) {
        X509_STORE_CTX *ctx = X509_STORE_CTX_new();
        X509_STORE_CTX_init(ctx, store, cert, NULL);
        double t0 = phc_now_ms();
        int ok = X509_verify_cert(ctx) == 1;
        double t_x509 = phc_now_ms() - t0;
        if (!ok) {
            fprintf(stderr, "X.509 verification failed: %s\n",
                    X509_verify_cert_error_string(X509_STORE_CTX_get_error(ctx)));
            return 1;
        }
        STACK_OF(X509) *chain = X509_STORE_CTX_get1_chain(ctx);
        t0 = phc_now_ms();
        ok = phc_verify_chain(chain, 0);
        double t_hyb = phc_now_ms() - t0;
        if (!ok) {
            fprintf(stderr, "hybrid verification failed\n");
            return 1;
        }
        fprintf(csv, "%s,%s,%s,%d,%.4f,%.4f,%d\n", g_host, model, phase(i, n, warmup), i, t_x509, t_hyb,
                sk_X509_num(chain));
        OSSL_STACK_OF_X509_free(chain);
        X509_STORE_CTX_free(ctx);
    }
    fclose(csv);
    printf("verify %s: %d iterations -> %s\n", model, n, argv[7]);
    return 0;
}

/* ---------------- TLS ---------------- */

static const char *chain_policy(void)
{
    const char *c = getenv("PHC_CHAIN");
    return (c && strcmp(c, "explicit") == 0) ? "explicit" : "auto";
}

static SSL_CTX *bench_ctx(int is_server, const char *cert, const char *key, const char *bundle)
{
    SSL_CTX *ctx = phc_tls_ctx(is_server, cert, key, bundle);
    if (!ctx)
        return NULL;
    /* Same key exchange for every model: only authentication differs. No resumption. */
    if (SSL_CTX_set1_groups_list(ctx, "X25519") != 1) {
        ERR_print_errors_fp(stderr);
        SSL_CTX_free(ctx);
        return NULL;
    }
    SSL_CTX_set_num_tickets(ctx, 0);
    SSL_CTX_set_options(ctx, SSL_OP_NO_TICKET);
    SSL_CTX_set_session_cache_mode(ctx, SSL_SESS_CACHE_OFF);
    if (strcmp(chain_policy(), "explicit") == 0)
        SSL_CTX_set_mode(ctx, SSL_MODE_NO_AUTO_CHAIN);
    return ctx;
}

static int cmd_tls_server(int argc, char **argv)
{
    if (argc != 6) {
        fprintf(stderr, "usage: phc-bench tls-server <port> <cert> <key> <ca-bundle>\n");
        return 2;
    }
    SSL_CTX *ctx = bench_ctx(1, argv[3], argv[4], argv[5]);
    int srv = ctx ? phc_listen(atoi(argv[2])) : -1;
    if (srv < 0)
        return 1;
    printf("[bench-server] listening on port %s, chain policy %s (Ctrl+C to stop)\n", argv[2], chain_policy());
    long served = 0, failed = 0;
    for (;;) {
        int fd = accept(srv, NULL, NULL);
        if (fd < 0)
            continue;
        int one = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
        SSL *ssl = SSL_new(ctx);
        SSL_set_fd(ssl, fd);
        int ok = SSL_accept(ssl) == 1 && phc_verify_chain(SSL_get0_verified_chain(ssl), 0) == 1;
        if (ok) {
            served++;
            SSL_shutdown(ssl);
        } else {
            failed++;
            ERR_clear_error();
        }
        SSL_free(ssl);
        close(fd);
        if ((served + failed) % 50 == 0)
            printf("[bench-server] connections: %ld ok, %ld failed\n", served, failed);
    }
}

static int tcp_connect(const char *host, int port)
{
    struct addrinfo hints = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM}, *res;
    char p[8];
    snprintf(p, sizeof p, "%d", port);
    if (getaddrinfo(host, p, &hints, &res) != 0)
        return -1;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd >= 0 && connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd >= 0) {
        int one = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one);
    }
    return fd;
}

static int cmd_tls_client(int argc, char **argv)
{
    if (argc != 11) {
        fprintf(stderr, "usage: phc-bench tls-client <model> <host> <port> <cert> <key> <ca-bundle> <n> <warmup> <csv>\n");
        return 2;
    }
    const char *model = argv[2], *host = argv[3];
    int port = atoi(argv[4]), n = atoi(argv[8]), warmup = atoi(argv[9]);
    const char *pe = getenv("PHC_BENCH_PAUSE_MS");
    int pause_ms = pe ? atoi(pe) : 0;
    SSL_CTX *ctx = bench_ctx(0, argv[5], argv[6], argv[7]);
    if (!ctx)
        return 1;
    FILE *csv = open_csv(argv[10], "host,model,chain,pause_ms,phase,iter,tcp_ms,handshake_ms,hybrid_ms,total_ms,"
                                    "hs_bytes_sent,hs_bytes_recv,peer_chain_certs,group,cipher");
    int failures = 0;
    for (int i = 0; i < n; i++) {
        double t0 = phc_now_ms();
        int fd = tcp_connect(host, port);
        if (fd < 0) {
            fprintf(stderr, "connect failed (iteration %d): %s\n", i, strerror(errno));
            return 1;
        }
        double t1 = phc_now_ms();
        BIO *bio = BIO_new_socket(fd, BIO_NOCLOSE);
        SSL *ssl = SSL_new(ctx);
        SSL_set_bio(ssl, bio, bio);
        int ok = SSL_connect(ssl) == 1;
        double t2 = phc_now_ms();
        int hyb = ok ? phc_verify_chain(SSL_get0_verified_chain(ssl), 0) : 0;
        double t3 = phc_now_ms();
        if (!ok || hyb != 1) {
            fprintf(stderr, "iteration %d: %s\n", i, ok ? "hybrid verification failed" : "handshake failed");
            ERR_print_errors_fp(stderr);
            failures++;
        } else {
            char group[64] = "?";
            int nid = SSL_get_negotiated_group(ssl);
            const char *gname = SSL_group_to_name(ssl, nid);
            if (gname)
                snprintf(group, sizeof group, "%s", gname);
            STACK_OF(X509) *sent = SSL_get_peer_cert_chain(ssl);
            fprintf(csv, "%s,%s,%s,%d,%s,%d,%.4f,%.4f,%.4f,%.4f,%lu,%lu,%d,%s,%s\n", g_host, model, chain_policy(),
                    pause_ms, phase(i, n, warmup), i, t1 - t0, t2 - t1, t3 - t2, t3 - t0,
                    (unsigned long)BIO_number_written(bio), (unsigned long)BIO_number_read(bio),
                    sent ? sk_X509_num(sent) : 0, group, SSL_get_cipher(ssl));
            SSL_shutdown(ssl);
        }
        SSL_free(ssl);
        close(fd);
        if (pause_ms > 0)
            usleep((useconds_t)pause_ms * 1000);
    }
    fclose(csv);
    printf("tls-client %s: %d handshakes, %d failed -> %s\n", model, n, failures, argv[10]);
    return failures ? 1 : 0;
}

int main(int argc, char **argv)
{
    signal(SIGPIPE, SIG_IGN);
    setvbuf(stdout, NULL, _IOLBF, 0);
    gethostname(g_host, sizeof g_host - 1);
    if (argc >= 2 && strcmp(argv[1], "sig") == 0)
        return cmd_sig(argc, argv);
    if (argc >= 2 && strcmp(argv[1], "verify") == 0)
        return cmd_verify(argc, argv);
    if (argc >= 2 && strcmp(argv[1], "tls-server") == 0)
        return cmd_tls_server(argc, argv);
    if (argc >= 2 && strcmp(argv[1], "tls-client") == 0)
        return cmd_tls_client(argc, argv);
    fprintf(stderr, "usage: phc-bench sig|verify|tls-server|tls-client ... (see source header)\n");
    return 2;
}
