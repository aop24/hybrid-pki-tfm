#!/usr/bin/env python3
"""Block 14 - propagation delay of each revocation, from the revocation log of the CA
(14-revocations.csv) and the polls of the clients (14-raw-poll.csv).
For each poll series (column model = label) the revocation event used is the last one of that
model before the first REVOKED poll. delay_ms = first REVOKED poll - revocation; the bound
"last good poll" gives the uncertainty interval of the measure.
Usage: python3 -I 14-propagation.py <14-revocations.csv> <output.csv> <14-raw-poll-*.csv>..."""
import csv, sys
from collections import defaultdict
rev = [r for r in csv.DictReader(open(sys.argv[1]))]
polls = defaultdict(list)
for path in sys.argv[3:]:
    for r in csv.DictReader(open(path)):
        polls[r["model"]].append(r)
out = []
for label, rows in polls.items():
    model = label.split("-")[0]
    first = next((r for r in rows if r["status"] == "REVOKED"), None)
    if not first:
        out.append([label, model, rows[0]["method"], "", "", "", "", "not observed", len(rows)])
        continue
    tf = int(first["epoch_ms"])
    cands = [r for r in rev if r["event"] == "revoked" and r["model"] == model and int(r["epoch_ms"]) <= tf]
    if not cands:
        out.append([label, model, first["method"], "", first["utc"], "", "", "no revocation logged before", len(rows)])
        continue
    ev = max(cands, key=lambda r: int(r["epoch_ms"]))
    t0 = int(ev["epoch_ms"])
    last_good = max((int(r["epoch_ms"]) for r in rows if r["status"] == "good" and int(r["epoch_ms"]) <= tf), default=None)
    pubs = [r for r in rev if r["event"] == "crl_published" and r["model"] == model and t0 <= int(r["epoch_ms"]) <= tf]
    note = f"after CRL published at {pubs[-1]['utc']}" if pubs else ""
    out.append([label, model, first["method"], ev["utc"], first["utc"], tf - t0,
                (last_good - t0) if last_good is not None else "", note, len(rows)])
with open(sys.argv[2], "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["series", "model", "method", "revoked_utc", "first_revoked_poll_utc", "delay_ms", "last_good_poll_minus_revocation_ms", "notes", "polls"])
    w.writerows(out)
for r in out:
    print(" | ".join(str(x) for x in r))
